//converts the current time in Asia/Kolkata to Eastern Standard Time (ET) in the United States:
// const date = new Date(); // create a new Date object with the current date and time
// const options = { timeZone: "America/New_York" }; // set the timeZone option to "America/New_York" for Eastern Standard Time
// const dateString = date.toLocaleString("en-IN", options); // format the date and time in the india timezone//en-US for US format
// console.log(dateString);

// Create a Date object for the current date and time:
// 	*Get the year,month,dayOfMonth,dayOfWeek,hours,minutes,seconds,milliseconds from a Date object and print individually in console.

const date = new Date();//ends with z , UTC time 5 :30hrs approx..(GMT)
const options = { timeZone: "Asia/Kolkata" }; // set the timeZone option to "America/New_York" for Eastern Standard Time
const dateString = date.toLocaleString("en-IN", options);
console.log(dateString);
//const date1 = new Date(dateString);
//console.log(date1);

const year = date.getFullYear();
console.log(year);
const month = date.getMonth();0,1,2
console.log(month);
const dayOfMonth = date.getDate();
console.log(dayOfMonth);
const dayOfWeek = date.getDay();
console.log(dayOfWeek);
const hours = date.getHours();
console.log(hours);
const minutes = date.getMinutes();
console.log(minutes);
const seconds = date.getSeconds();
console.log(seconds);
const milliseconds = date.getMilliseconds();
console.log(milliseconds);



//America/Los_Angeles
//"Asia/Kolkata"
// There are many different time zones in use around the world. Here are some examples of other time zones:

// Pacific Standard Time (PST): This is the time zone used on the West Coast of the United States and Canada, including cities such as Los Angeles, San Francisco, and Vancouver.

// Eastern Standard Time (EST): This is the time zone used on the East Coast of the United States and Canada, including cities such as New York, Washington D.C., and Toronto.

// Central European Time (CET): This is the time zone used in much of Europe, including cities such as Paris, Berlin, and Rome.

// Greenwich Mean Time (GMT): This is the time zone used in the United Kingdom and Ireland.

// Australian Eastern Standard Time (AEST): This is the time zone used in much of Australia, including cities such as Sydney, Melbourne, and Brisbane.

// Japan Standard Time (JST): This is the time zone used in Japan, including cities such as Tokyo and Osaka.

// Indian Standard Time (IST): This is the time zone used in India, including cities such as Mumbai, Delhi, and Bangalore.

// Central Standard Time (CST): This is the time zone used in much of Central America, including cities such as Mexico City and Guatemala City.

// Australian Central Standard Time (ACST): This is the time zone used in the central region of Australia, including cities such as Adelaide and Darwin.

// Eastern Africa Time (EAT): This is the time zone used in much of East Africa, including cities such as Nairobi and Dar es Salaam.