function arrayinsert(qid1,value)
{
    studentanswers=[{ qid:27, ans: ['Answer4']},{ qid:24, ans: ['Answer5']}]
    console.log(studentanswers[0].qid)
    //let qid1 = 27;
    //let value = "some value";
    value1=[value]
    let flagans=false;
    for (let i = 0; i < studentanswers.length; i++) {
      if (studentanswers[i].qid === qid1) {
        studentanswers[i].ans.push(value1[0]);
        console.log(studentanswers)
        flagans=true;
        break;
      }
    }
    if(flagans==false)
    {
        let studentanswers1={qid:qid1,ans:value1};
        console.log("studentanswers1",studentanswers1)
        studentanswers.push(studentanswers1)
        console.log(studentanswers)

       //fill your logic here
      }
}

arrayinsert(27,'answer8');