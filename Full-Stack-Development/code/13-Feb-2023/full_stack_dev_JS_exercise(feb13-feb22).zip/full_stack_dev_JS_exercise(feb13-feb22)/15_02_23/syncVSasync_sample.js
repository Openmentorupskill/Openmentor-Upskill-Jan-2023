const fs = require('fs');

// // Synchronous file write
// fs.writeFile('E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/15_02_23/myfilesample.txt', 'This is synchronous file write.');
// console.log("write completed ")
// // Synchronous file read
// const syncData = fs.readFileSync('E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/15_02_23/myfilesample.txt', 'utf8');
// console.log(syncData);

setTimeout(() => {
    fs.writeFileSync('E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/15_02_23/myfilesample.txt',
     'Hello, world!\r\n',{ flag: 'a' }); //used flag to append
  console.log("file write complete sync")
}, 5000);
console.log("file write after complete sync")

setTimeout(() => {
    fs.writeFile('E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/15_02_23/myfilesample.txt', 'This is asynchronous file write.', (err) => {
        if (err) throw err;
        console.log('File written successfully!');
      });
      
      // Asynchronous file read
      fs.readFile('E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/15_02_23/myfilesample.txt', 'utf8', (err, data) => {
        if (err) throw err;
        console.log(data);
      });
}, 5000);

console.log("file write complete")


