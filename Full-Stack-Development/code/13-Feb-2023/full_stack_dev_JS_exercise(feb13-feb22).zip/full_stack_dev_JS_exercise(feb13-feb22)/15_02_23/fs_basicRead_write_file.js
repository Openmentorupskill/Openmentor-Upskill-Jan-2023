//Create a new file: Use the fs.writeFile function to create a new file with the content "Hello, world!".
const fs = require('fs');

fs.writeFile('E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/15_02_23/myfilesample.txt','Hello,Openmentor!', (err) => {
  if (err) throw err;
  console.log('File created');
});
// //.Read a file: Use the fs.readFile function to read the contents of a above file and print them to the console.
// fs.readFile('E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/15_02_23/myfilesample.txt', (err, data) => {
//     if (err) throw err;
//     console.log(data.toString());
//   });

// //Append to a file: Use the fs.appendFile function to append the text "Goodbye, world!" to an above created file.
// fs.appendFile('E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/15_02_23/myfilesample.txt', 'Goodbye,have a nice day!', (err) => {
//     if (err) throw err;
//     console.log('Text appended to file');
//   });

//.Rename a file: Use the fs.rename function to rename above created file from "myfile.txt" to "newfile.txt".
//     fs.rename('E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/15_02_23/myfilesample.txt', 'newfilesample.txt', (err) => {
//     if (err) throw err;
//     console.log('File renamed');
//   });

// //	.Delete a file: Use the fs.unlink function to delete a above created file.
//   fs.unlink('E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/15_02_23/newfilesample.txt', (err) => {
//     if (err) throw err;
//     console.log('File deleted');
//   });

