function formatPhoneNumber(person) {
    const areaCode = person.phone.areaCode;// person[phone][areacode]
    const phoneNumber = person.phone.number;
    return `(${areaCode}) ${phoneNumber}`;
  }

  const person = {
    "name": "John Smith",
    "email": "john.smith@example.com",
    "phone": {
      "areaCode": "555",
      "number": "123-4567"
    }
  };
  const phoneNumber = formatPhoneNumber(person);
  console.log(phoneNumber)
  // to print in json format
  let str={"PhoneNumber":phoneNumber}
  console.log(str); // Output: (555) 123-4567
  