//create new file which contain many datas or took one existing file with many datas, 
//use setInterval to read from a file every 5 seconds and print in console.
//UTF-8 can represent any character in the Unicode standard. UTF-8 is backwards compatible with ASCII.
const fs = require('fs');

// setInterval(() => {
//   const data = fs.readFileSync('E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/15_02_23/myfilesample.txt', 'utf8');
//   console.log(data);
// }, 5000);


//using setTimeout to write to the above file after a delay of 10 seconds into a new file
setTimeout(() => {
    fs.writeFileSync('E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/15_02_23/myfilesample.txt',
     'Hello, world!\r\n',{ flag: 'a' }); //used flag to append
  console.log("file write complete")
}, 5000);



// while synchronous methods like fs.writeFileSync() can be convenient for small operations or scripts, 
//they can cause performance issues in larger applications or when handling many I/O operations.
// In general, it's recommended to use the asynchronous versions of 
//these methods (fs.writeFile(), fs.appendFile()) or consider using streams for large I/O operations.

