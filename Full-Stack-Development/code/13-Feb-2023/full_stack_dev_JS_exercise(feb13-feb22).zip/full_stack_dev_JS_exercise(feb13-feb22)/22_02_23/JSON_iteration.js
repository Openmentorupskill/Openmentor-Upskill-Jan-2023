const movies = [
    {
      "title": "movie1",
      "year": 1994,
      "actors": [
        { "name": "Tim", "age": 62 },
        { "name": "Morgan ", "age": 84 },
        { "name": "Bob", "age": 76 }
      ]
    },
    {
      "title": "movie2",
      "year": 1972,
      "actors": [
        { "name": "Brando", "age": 80 },
        { "name": "Pacino", "age": 82 },
        { "name": "James", "age": 81 }
      ]
    },
    {
      "title": "movie3",
      "year": 2008,
      "actors": [
        { "name": "Christian ", "age": 47 },
        { "name": "Heath", "age": 28 },
        { "name": "Aaron", "age": 53 }
      ]
    }
  ];
  
  function formatMovies(movies) {
    return movies.map(movie => {
      const actors = movie.actors.map(actor => actor.name).join(', ');
      return `${movie.title} (${movie.year}) - Starring: ${actors}`;
    });
  }


  //mvarr=["The Shawshank Redemption"]
  res=formatMovies(movies);
  console.log(res)



  

  //map() method in JavaScript is used to iterate over an array and return a new array with the same length, 
  //where each element is transformed based on a callback function.


//   const data = [
//     { id: 1, name: 'John', age: 30 },
//     { id: 2, name: 'Jane', age: 25 },
//     { id: 3, name: 'Bob', age: 40 }
//   ];

//   const names = data.map(person => person.name);
// console.log(names);

// const transformedData = data.map(person => {
//     return {
//       id: person.id,
//       name: person.name.toUpperCase(),
//       age: person.age * 2
//     };
//   });
//   console.log(transformedData);