//array intersection
// Write a function that takes two arrays of numbers as input 
// and returns a Set of all the numbers that appear in both arrays.

function intersection(array1, array2) {
    const set1 = new Set(array1);
    const set2 = new Set(array2);
    return new Set([...set1].filter(x => set2.has(x)));
  }
  
  console.log(intersection([1, 2, 3], [3, 4, 5]));


//   Write a function that takes two arrays of numbers 
//   as input and returns a Set of all the numbers that appear in the first array but not in the second array

  function difference(array1, array2) {
    const set1 = new Set(array1);
    const set2 = new Set(array2);
    return new Set([...set1].filter(x => !set2.has(x)));
  }
  
  console.log(difference([1, 2, 3], [3, 4, 5]));


res=[];
for(let i of set1)
{if(set2.has(i))
    res.push(i)

}


  