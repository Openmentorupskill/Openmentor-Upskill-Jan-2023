//Create a Map to store the frequency of letters in a string. 
//Write a function that takes a string as input
// and returns a Map with the frequency of each letter in the string.

function letterFrequency(str) {
  const frequency = new Map();
  for (const char of str) {//openmentor
    if (frequency.has(char)) {
      frequency.set(char, frequency.get(char) + 1);
    } else {
      frequency.set(char, 1);
    }
    //console.log(frequency)
  }
  return frequency;
}
console.log(letterFrequency('openmentor'));



// Map object has several in-built methods that allow you to perform operations on the map. Here is a list of some of the most commonly used methods:

// map.set(key, value): This method sets the value for the key in the map.

// map.get(key): This method returns the value associated with the given key, or undefined if the key is not in the map.

// map.has(key): This method returns a boolean indicating whether the given key is in the map.

// map.delete(key): This method deletes the key-value pair associated with the given key.

// map.clear(): This method removes all key-value pairs from the map.

// map.size: This property returns the number of key-value pairs in the map.

// map.keys(): This method returns a new Iterator object that contains the keys for each element in the map in insertion order.

// map.values(): This method returns a new Iterator object that contains the values for each element in the map in insertion order.

// map.entries(): This method returns a new Iterator object that contains the key-value pairs for each element in the map in insertion order











// Output: Map { 'h' => 1, 'e' => 1, 'l' => 2, 'o' => 1 }




// Create a Map to store the products in a shopping cart. 
//Write a function that takes an array of objects with 
//product information as input and returns a Map with the product name as 
//the key and the product information as the value.

// function createShoppingCart(products) {
//   const shoppingCart = new Map();
//   for (const product of products) {
//     shoppingCart.set(product.name, product);
//   }
//   return shoppingCart;
// }

// const products = [
//   { name: 'Apples', price: 0.99 },
//   { name: 'Bananas', price: 0.49 },
//   { name: 'Cherries', price: 1.99 },
// ];

// console.log(createShoppingCart(products));
// /* Output: 
// Map {
//   'Apples' => { name: 'Apples', price: 0.99 },
//   'Bananas' => { name: 'Bananas', price: 0.49 },
//   'Cherries' => { name: 'Cherries', price: 1.99 }
// }
// */



// Create a Map to store the names and ages of your friends. 
// Write a function that takes a name as input and returns the age of the friend with that name.
// function findFriend(friends, name) {
//   return friends.get(name);
// }

// const friends = new Map();
// friends.set('John', 30);
// friends.set('Jane', 28);
// friends.set('Jim', 35);

// console.log(findFriend(friends, 'John')); // Output: 30
// console.log(findFriend(friends, 'Jane')); // Output: 28
// console.log(findFriend(friends, 'Jim')); // Output: 35
