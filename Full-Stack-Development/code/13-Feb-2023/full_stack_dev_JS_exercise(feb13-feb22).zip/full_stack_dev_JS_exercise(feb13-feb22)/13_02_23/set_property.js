// size: Returns the number of elements in the Set.

// add(value): Adds a new value to the Set. If the value is already in the Set, it won't be added again.

// delete(value): Removes a value from the Set.

// clear(): Removes all elements from the Set.

// has(value): Returns a boolean indicating whether the Set contains a particular value.

// values(): Returns an iterator object containing all values in the Set, in insertion order.

// entries(): Returns an iterator object containing all values in the Set, in insertion order, as an array of [value, value].

// forEach(callbackFn): Calls a provided callback function once for each value in the Set, in insertion order.

// Note that Sets do not have any ordering, so the order in which values are returned by the 
//values() or entries() methods may not match the order in which the values were inserted into the Set. 
//Also, Sets are unordered, so the values are not indexed like in an Array.







//Write a function that takes an array of numbers as input and returns a Set of all the unique numbers in the array.
function getUniqueNumbers(numbers) {
    return new Set(numbers);
  }
  
  console.log(getUniqueNumbers([1, 2, 3, 4, 4, 5, 5, 6, 6]));

//Union- ARRAY
// Write a function that takes two arrays of numbers as input and 
//returns a Set of all the numbers that appear in either array.
function unionarr(array1, array2) {
    return new Set([...array1, ...array2]);
  }
  
console.log(unionarr([1, 2, 3], [3, 4, 5]));// [1,2,3,3,4,5]

  function unionarr1(array1, array2) {
    return arr=[...array1, ...array2];
  }
  
  console.log(unionarr1([1, 2, 3], [3, 4, 5]));

  