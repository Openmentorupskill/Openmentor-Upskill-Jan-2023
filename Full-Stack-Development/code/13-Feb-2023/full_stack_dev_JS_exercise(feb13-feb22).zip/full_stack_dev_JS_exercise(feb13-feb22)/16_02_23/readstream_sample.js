//Write a Node.js program that reads a file using a readStream, and outputs the file contents to the console.


const fs = require('fs');

const readStream = fs.createReadStream('D:/backup_kaushiksir_drive/flight_weather_merge_2010/flightWeatherMerge_2010_15cols.csv');

readStream.on('data', (chunk) => {
  console.log(chunk.toString());
});

readStream.on('end', () => {
  console.log('Finished reading file.');
});

readStream.on('error', (err) => {
  console.error(`Error reading file: ${err.message}`);
});


