//write a program that uses both readStream and readline. 
//The program reads a file using a readStream, and then passes the readStream object to a 
//readline interface to read the file line by line and output the contents to the console.


const fs = require('fs');
const readline = require('readline');

const rs = fs.createReadStream('D:/backup_kaushiksir_drive/flight_weather_merge_2010/flightWeatherMerge_2010_15cols.csv');
const rl = readline.createInterface({
  input: rs,
  crlfDelay: Infinity
});

rl.on('line', (line) => {
  console.log(`Line from file: ${line}`);
});

rl.on('close', () => {
  console.log('Finished reading file.');
});
