//Write a Node.js program that prompts the user to enter a number using readline,
// and then prints the Fibonacci sequence up to that number to the console.
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question('Enter a number: ', (answer) => {//0,1,1,2,3,5,8
  const num = parseInt(answer);

  if (isNaN(num) || num <= 0) {
    console.error('Please enter a positive integer.');
  } else {
    const fib = [0, 1];
    while (fib[fib.length - 1] <= num) {
      fib.push(fib[fib.length - 1] + fib[fib.length - 2]);//
    }
    console.log(`The Fibonacci sequence up to ${num} is: ${fib.slice(0, -1).join(', ')}`);
  }

  rl.close();
});


