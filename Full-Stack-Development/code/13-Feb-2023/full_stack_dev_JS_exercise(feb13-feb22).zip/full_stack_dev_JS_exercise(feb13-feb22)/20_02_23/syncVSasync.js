async function fun1()
{
    console.log("a");
}
async function fun2()
{
//async/await and Promise in JavaScript do not assign processes to child threads automatically. 
//They provide a way to work with asynchronous operations in a non-blocking manner    
return new Promise(resolve => {
        setTimeout(() => {
            console.log("b -  starts")
            for(var i=0; i<2000000000; i++); // delay
            console.log("b - completes")
            resolve();
        }
        ,0);
    });
}
async function fun3()
{
    console.log("c");
}

async function main()
{
    fun1();
    //fun2();
    await fun2();
    fun3();
}

main();


// Promise is an object that represents a value that may not be available yet, but will be resolved eventually. 
//It is commonly used to handle asynchronous operations, such as making an HTTP request or reading a file from disk.

// A Promise can be in one of three states:

// Pending: The initial state of a Promise, before it has been resolved or rejected.
// Fulfilled: The state of a Promise when it has been successfully resolved with a value.
// Rejected: The state of a Promise when it has been unsuccessfully resolved with a reason (usually an error).
// A Promise is said to be "settled" when it is either fulfilled or rejected.

// When working with Promises, you typically create a new Promise object and pass it a 
//function that performs an asynchronous operation. The function should call the resolve
// function with the resolved value when the operation is successful, 
//or the reject function with the reason for the failure if the operation is unsuccessful. 
//You can then use the Promise's then and catch methods to handle the fulfilled and 
//rejected states, respectively.

