//  var x=3;
// console.log("before",x)
// console.log("inconsole",x++);//post
// console.log("after",x)
//  ++x;
//  console.log("perinc",x++)

// ++/-- x++... post -->returns the original value and then increment /dec
// ++/-- ++x ..pre--> increment/dec then return





// let y = x++ + ++x + ++x + x++;
//      //5+7+8+8
// console.log("y",y)
//y = ++x + ++x + x++ + x++ + ++x;
//    6+7+7+8+10

//let y = x++ + ++x + ++x + x++;
        //5+(6+1) +(7+1) +8=28
let x = 5;

y = x-- - --x + --x - x--;
// 5-(4-1)+(3-1)-2
// 5-3+2-2
// 2+2-2
// 2
console.log(y)

let date = new Date("2022-02-30");
console.log(date.getSeconds());   