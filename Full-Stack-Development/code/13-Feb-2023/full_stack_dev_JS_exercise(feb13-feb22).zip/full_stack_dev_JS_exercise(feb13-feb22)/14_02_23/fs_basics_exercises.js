//The fs.resolve() method is a part of the fs module and is used to resolve a list of paths or path segments into an absolute path.

const fs = require('fs');
const path= require('path')


//resolve
// let p=path.resolve(path.join("E:","job"))
// console.log(p,__dirname)
// let chkdir=fs.existsSync(p)
// console.log("dir exist?",chkdir)

// if (!fs.existsSync(p))
// {fs.mkdirSync(p,{ recursive: true })}

//1)


function joinpath(dirPath,filePath)
{
const fullPath = path.join(dirPath, filePath);
return fullPath;
}
const dirPath = '/home/user';
const filePath1 = 'documents/myfile.txt';
let fullPath1=joinpath(dirPath,filePath1)
console.log("fullpath",fullPath1);
// Output: /home/user/


// // Use the path.basename() method to extract the base name of a file from a given path.
 //console.log(path.basename('/tmp/file.txt')); 

// // Create a function that takes a path as an argument and returns the base name of the file.
// function getBaseName(filePath) {
//   return path.basename(filePath);
// }

// console.log(getBaseName('/tmp/file.txt')); 



// // Use the path.dirname() method to extract the directory name from a given path.
console.log(path.dirname('/tmp/file.txt'));  // Output: '/tmp'

//  Create a function that takes a path as an argument and returns the directory name.
// function getDirectoryName(filePath) {
//   return path.dirname(filePath);
// }

// console.log(getDirectoryName('/tmp/file.txt')); 



// Use the path.isAbsolute() method to check if a given path is an absolute path.

// console.log(path.isAbsolute('/abc/tmp123/file.txt'));  // Output: true
// console.log(path.isAbsolute('abc/tmp123/file.txt'));  // Output: false
// Create a function that takes a path as an argument and returns a Boolean indicating whether the path is absolute or not.
// function isAbsolutePath(filePath) {
//   return path.isAbsolute(filePath);
// }

// console.log(isAbsolutePath('/abc/tmp123/file.txt')); 


// use the fs (File System) module to check if a file or directory exists
//fs.access( path, mode, callback )
// callback: It is a function that would be called when the method is executed. 
// err: It is an error that would be thrown if the method fails.

//const filePath = '/tmp/file.txt';
const filePath = 'E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/14_02_23/fs_basics_exercises.js';

fs.access(filePath, fs.constants.F_OK, (err) => {
  if (err) {
    console.log(`${filePath} does not exist`);
  } else {
    console.log(`${filePath} exists`);
  }
});




