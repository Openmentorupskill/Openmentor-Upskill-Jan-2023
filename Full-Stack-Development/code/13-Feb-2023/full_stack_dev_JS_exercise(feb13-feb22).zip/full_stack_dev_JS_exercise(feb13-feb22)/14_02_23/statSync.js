//const fs = require('fs');
//Create a new .js file and require the fs module:
const fs = require('fs');
//Use fs.statSync to retrieve information about a file:

const fileStats = fs.statSync('E:/job/tasks/naan mudalvan/JS_Practice_exercises/NMclass_exercise_js_pgms/09_02_23/reverse_num.js');
//Log the information about the file to the console:

console.log(fileStats);
//Check if the file is a directory:

console.log(fileStats.isDirectory());
//Check if the file is a regular file:

console.log(fileStats.isFile());
//Log the size of the file:

console.log(fileStats.size);
//Log the creation time of the file:

console.log(fileStats.ctime);