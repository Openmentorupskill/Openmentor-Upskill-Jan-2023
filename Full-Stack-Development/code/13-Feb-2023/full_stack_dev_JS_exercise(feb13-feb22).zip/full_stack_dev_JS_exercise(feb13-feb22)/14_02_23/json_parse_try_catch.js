// try below code with and without try catch block
try {
    //const jsonString = '{"name": "John", "age": 30}';
    //const user = JSON.parse(jsonString);
    const user=JSON.parse('{"foo": 01}');
   
    console.log(`Name: ${user.name}`);
    console.log(`Age: ${user.age}`);
}
catch (error) {
    console.error(`Error: ${error.message}`);
}

function fun() {
    const jsonString = '{"name": "John", "age": 30}';
    const user1 = JSON.parse(jsonString);
    console.log(`Name: ${user1.name}`);
    console.log(`Age: ${user1.age}`);
}
fun();
  // parse error will raise during
  //You cannot use leading zeros, like 01, and decimal points must be followed by at least one digit.
  //unterminated fractional number eg: JSON.parse('{"foo": 1.}');
//You cannot use single-quotes around properties, like  JSON.parse("{'foo': 1}");


//try-catch-finally
// try {
//     const num1 = 10;
//     const num2 = a;
//     if (num2 === 0) {
//       throw new Error("Cannot divide by zero");
//     }
//     const result = num1 / num2;
//     console.log(result);
//   } catch (error) {
//     console.error(`Error: ${error.message}`);
//   } finally {
//     console.log("Execution continues after the error");
//   }