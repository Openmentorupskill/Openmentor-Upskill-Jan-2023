// reverse the given number 
// function reverse_a_number(n)
// {
// 	n = n + "";
// 	return n.split("").reverse().join(""); ['3','2','2','4','3'].reverse()
// }
// console.log(Number(reverse_a_number(32243)));
function reverse(arr)
{
    let rev="";
    for(let i=arr.length-1; i>=0 ; i--)
    {
        rev+=arr[i]
    }
return rev
}

let arr=[4,3,2,1]
console.log(reverse(arr))
// for(i=0;i<33;i++)

// ['3','2','2','4','3']
    // 0   1   2   3   4









//The split() method is used to split a String object into an array of 
//strings by separating the string into substrings.
//'1234'.split("") will gives  ["1", "2", "3", "4"]
//The join() method is used to join all elements of an array into a string.
//["1", "2", "3", "4"].join("") will gives 1234

//reverse array
// function reverse_a_number(arr)
// {
	
// 	return arr.reverse();
// }
// let arr= ["1", "2", "3", "4"]
// console.log(reverse_a_number(arr));