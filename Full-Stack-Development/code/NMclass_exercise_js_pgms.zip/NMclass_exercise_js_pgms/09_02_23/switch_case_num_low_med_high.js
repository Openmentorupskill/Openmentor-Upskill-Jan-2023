// The switch expression is evaluated once.
// The value of the expression is compared with the values of each case.
// If find a match, the associated block of code is executed.
// If there is no match, the default code block is executed.
function switchcase(num1)
{
switch (true) {
    case (num1 < 10):
        console.log("Number is very low");
        break;
    case (num1 >=11) && (num1 <=50):  //&& operator both condition must be true (11,13..........50)
        console.log("Number is low");
        break;
    case (num1 >=51) && (num1 <=99): 
        console.log("Number is medium");
        break;
    case (num1 >=100):
            console.log("Number is high");
            break;
    default: //If there is no match, the default code block is executed.
        console.log("enter valid number")
}
}
let num1 =222222;
switchcase(num1)