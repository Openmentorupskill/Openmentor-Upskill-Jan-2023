var array =["im1","im2","im3","im4"]
console.log(array);
rotations=5;
for(i=0;i<rotations;i++)
{
    var ele=array.pop();
    array.unshift(ele)//im4//im3
    console.log(array);
}
