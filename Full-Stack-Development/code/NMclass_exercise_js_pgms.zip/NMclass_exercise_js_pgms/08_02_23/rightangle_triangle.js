
var x,y;
var chr="";
for(x=1; x <=6; x++)// row
{
   //for (y=1; y < x; y++)// column x=1
     //{
    chr=chr+"*";
    //line
    console.log(chr,"\n");
        
      //}
 //console.log(chr);
 //chr='';    
}
       


