// JSON object
let jsonObject = {
    "key1": "value1",
    "key2": "value2",
    "key3": "value3",
    "key1000": "value1000"
  };
  
  // Map object
  let mapObject = new Map();
  for (let i = 1; i <= jsonObject.length; i++) {
    mapObject.set("key" + i, "value" + i);
  }
  
  // Measure time to iterate over JSON object
  let startTimeJson = performance.now();
  for (let key in jsonObject) {
    let value = jsonObject[key];
    // Do something with key and value
  }
  let endTimeJson = performance.now();
  
  // Measure time to iterate over Map object
  let startTimeMap = performance.now();
  mapObject.forEach((value, key) => {
    // Do something with key and value
  });
  let endTimeMap = performance.now();
  
  // Compare times
  let timeJson = endTimeJson - startTimeJson;
  let timeMap = endTimeMap - startTimeMap;
  console.log("JSON object iteration time: " + timeJson + "ms");
  console.log("Map object iteration time: " + timeMap + "ms");
  
  //performance.now() method can be used 
  //to check the performance of your code. You can check the execution time of your code using this method.