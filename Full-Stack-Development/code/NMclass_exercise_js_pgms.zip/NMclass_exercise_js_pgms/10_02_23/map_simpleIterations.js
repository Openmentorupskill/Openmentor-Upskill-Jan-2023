let fruitPrices = new Map();
fruitPrices.set("banana", 1.5);
fruitPrices.set("apple", 2.5);
fruitPrices.set("orange", 3);
//to insert new item
fruitPrices.set("mango", 4);
// to get value of particular key
console.log(fruitPrices.get("apple")); // 2.5
console.log(fruitPrices.has("apple")); // 2.5

//console.log(fruitPrices)
fruitPrices.forEach((value, key) => {
    //console.log(key + ":" + value);
    //console.log(value);
     console.log(key);


  });

//   let userMap = new Map();
//   for (let i = 0; i < users.length; i++) {
//     userMap.set(users[i].userId, users[i]);
//   }