var obj = {1:"Object Name", 2:"Test"};
console.log(obj);