let books = [  {title: "To Kill a Mockingbird", author: "Harper Lee"}, 
 {title: "The Great Gatsby", author: "F. Scott Fitzgerald"},  
 {title: "Pride and Prejudice", author: "Jane Austen"}];

for (let i = 0; i < books.length; i++) {
  console.log(books[i].title + " by " + books[i].author);
}





// simple iteration over json object
// let person = {
//     name: "John Doe",
//     age: 35,
//     city: "New York"
//   };
  
//   for (let key in person) {
//     console.log(key + ": " + person[key]);
//   }